BRUNA PROATIVA — RETIFICAÇÃO

1. O index.html desta pasta já está preparado para:
- não narrar código por voz; o código fica apenas no ecrã;
- mostrar o estado ATIVADA/DESATIVADA do modo Proativa;
- manter os botões e definições funcionais;
- instalar como aplicação PWA;
- pedir ao Cloudflare Worker a geração de imagem/vídeo e mostrar o ficheiro devolvido.

2. IMPORTANTE SOBRE IMAGENS/VÍDEO
A interface já faz o pedido de media ao Worker usando:
- action: generate_image
- action: generate_video

O Worker atual conhecido da Bruna só foi confirmado como endpoint de conversa e não foi disponibilizado o código dele. Para a geração real de imagem/vídeo funcionar, o Worker precisa aceitar essas ações e devolver JSON com imageUrl/image_url/url ou videoUrl/video_url/url.

Não coloque chaves de API no index.html. As chaves devem ficar no Cloudflare Worker.

3. PUBLICAÇÃO
O ficheiro principal deve chamar-se exatamente index.html e ficar na raiz do repositório GitHub Pages.
