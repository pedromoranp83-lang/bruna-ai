BRUNA — VERSÃO FINAL

1. Substituir o index.html do GitHub pelo index.html desta pasta.
2. Manter na mesma pasta:
   - manifest.webmanifest
   - service-worker.js
   - icon-192.png
   - icon-512.png
   - apple-touch-icon.png
3. Publicar no GitHub Pages em HTTPS.
4. Abrir a página publicada para usar microfone e instalação PWA.
5. O botão Instalar aparece no dock e também em Definições.
6. O botão de instalação depende do navegador permitir PWA; em Chrome/Edge pode também ser instalado pelo menu do navegador.
7. O ficheiro HTML local em C:/Downloads não é a versão instalada. Para PWA, usar o endereço HTTPS do GitHub Pages.
